import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Entrypoint for lambda
def main(event, context):
    logger.info('got event{}'.format(event))
    resp = make_all_buckets_private()
    logger.info('There were {} public buckets and {} were made private again'.format(resp[1], resp[0]))
    # TODO Check Bucket Policy
    # TODO Check Bucket CORS
    return resp


# Orchestrate the workflow
def make_all_buckets_private():
    bad_buckets = get_bad_buckets()
    success = True
    num_remediated = 0
    for bucket in bad_buckets:
        resp = make_private(bucket)
        if resp['ResponseMetadata']['HTTPStatusCode'] == 200:
            num_remediated += 1
    return (num_remediated, len(bad_buckets))


# Find all the buckets that are public
def get_bad_buckets():
    client = boto3.client("s3")
    bucket_resp = client.list_buckets()
    bucket_names = [x['Name'] for x in bucket_resp['Buckets']]

    bad_buckets = set()
    
    for bucket in bucket_names:
        grants = client.get_bucket_acl(Bucket=bucket)['Grants']
        for grant in grants:
            if grant['Grantee']['Type'].lower() == 'group':
                if 'http://acs.amazonaws.com/groups/global/' in grant['Grantee']['URI']:
                    bad_buckets.add(bucket)
                    logger.info('Found a public bucket: {}'.format(bucket))
    return bad_buckets


# Make a specific bucket private again
def make_private(bucket_name):
    client = boto3.client("s3")
    response = client.put_bucket_acl(ACL='private', Bucket=bucket_name)
    return response
