from __future__ import print_function

import json
import datetime
import time
import boto3
from random import randint
from time import sleep

def lambda_handler(event, context):
    
    #get autoscaling client
    asg_client = boto3.client('autoscaling')
    
    #get ec2 client
    ec2_client = boto3.client('ec2')

    #filter out ASGs based on name
    paginator = asg_client.get_paginator('describe_auto_scaling_groups')
    page_iterator = paginator.paginate(
        PaginationConfig={'PageSize': 100}
    )

    filtered_asgs = (page['AutoScalingGroupName'] for page in page_iterator.search("AutoScalingGroups[?contains(AutoScalingGroupName,`_public`)][]"))

    for asg in filtered_asgs:
        
        #randomizing sleep to prevent all ASGs in an account from being replaced at the exact same time
        sleep(randint(1,30))

        #get the latest saml_proxy AMI
        response = ec2_client.describe_images(Owners=['446745052017'], # AWS98
        Filters=[{'Name': 'name', 'Values': ['saml_base*']},],
        )

        amis = sorted(response['Images'], key=lambda x: x['CreationDate'], reverse=True)
        new_ami_id = amis[0]['ImageId']

        #get object for the ASG we're going to update, filter by name of target ASG
        asg_response = asg_client.describe_auto_scaling_groups(AutoScalingGroupNames=[asg])

        if not asg_response['AutoScalingGroups']:
            return 'No such ASG'

        #get name of InstanceID in current ASG that we'll use to model new Launch Configuration after
        try:
            source_instance_id = asg_response.get('AutoScalingGroups')[0]['Instances'][0]['InstanceId']    
           
            #get current AMI in use in ASG
            ec2_response = ec2_client.describe_instances(InstanceIds=[source_instance_id],)

            source_instance_ami = ec2_response.get('Reservations')[0]['Instances'][0]['ImageId']
        
            #get instance age
            source_instance_launch_time = ec2_response.get('Reservations')[0]['Instances'][0]['LaunchTime']
        
            #set time for sixty days ago
            sixty_days_ago = datetime.datetime.now() - datetime.timedelta(days=60)
        
            if source_instance_ami != new_ami_id and source_instance_launch_time.replace(tzinfo=None) < sixty_days_ago:
                
                print(asg)
            
                #create LC using instance from target ASG as a template, only diff is the name of the new LC and new AMI
                time_stamp = time.time()
                time_stamp_string = datetime.datetime.fromtimestamp(time_stamp).strftime('%Y-%m-%d%H%M%s')
                new_launch_config_name = asg + ' ' + 'LC' + ' ' + time_stamp_string
                asg_client.create_launch_configuration(
                    InstanceId = source_instance_id,
                    LaunchConfigurationName = new_launch_config_name,
                    ImageId = new_ami_id )

                #update ASG to use new LC
                response = asg_client.update_auto_scaling_group(AutoScalingGroupName = asg,LaunchConfigurationName = new_launch_config_name)
    
                #refresh instances in ASG
                response = asg_client.start_instance_refresh(
                AutoScalingGroupName = asg,
                Strategy='Rolling')
            
                print(f'Updated ASG {asg} with new launch configuration {new_launch_config_name} which includes AMI {new_ami_id} and also refreshed all instances in ASG')
            else:
                continue
            
        #Catch and log any errors thrown by the above block. Should be noted that ASGs with no instances in them will throw an IndexError
        except Exception as e:
            print(f'{asg} was not updated due to this error: {e}')
            pass    