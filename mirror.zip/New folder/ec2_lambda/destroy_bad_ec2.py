import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def main(event, context):
    logger.info('got event{}'.format(event))
    client = boto3.client("ec2")
    instance_id = event['detail']['instance-id']
    instance_res = client.describe_instances(InstanceIds=[instance_id])
    instance_ami = instance_res['Reservations'][0]['Instances'][0]['ImageId']
    image_res = client.describe_images(ImageIds=[instance_ami])
    image_acct = image_res['Images'][0]['OwnerId']
    if image_acct != '{{approved_image_account}}':
        client.terminate_instances(InstanceIds=[instance_id])
        logger.info(f"Terminated instance {instance_id}!  This instance is not from the approved account")
        logger.info(f"Image account was {image_acct}")
        return "Terminated"
    else:
        logger.info("Instance " + instance_id + " is from the approved account")
        return "Approved"
